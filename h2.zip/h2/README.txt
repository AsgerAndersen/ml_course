Author: Asger Andersen

I have implemented all my code in Python. I have used Jupyter Notebooks to write and run my code. 

In the folder illustration_of_hoeffding, there is a notebook by the name illustration_of_hoeffding.ipynb. When the entire notebook is run, all the results from the section Illustration of Hoeffding are reproduced. 

In the folder logistic_regression, there is a notebook by the name logistic_regression.ipynb. When the entire notebook is run, all the results from the section Logistic Regression are reproduced.