Author: Asger Andersen

I have implemented all my code in Python. I have used Jupyter Notebooks to write and run my code. 

In the folder svms, there is a notebook by the name svms.ipynb. When the entire notebook is run, all the results from the section svms are reproduced.