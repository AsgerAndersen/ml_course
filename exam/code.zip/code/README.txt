I only have one file with code, namely "main.py"

This file can be run in the terminal with the command:
"python main.py"

When run, it reproduces all plots and tables from my Exam Report. They are all saven in the folder "output".

In my code, I import the following modules:
- "pandas"
- "scipy"
- "scipy.spatial.distance.euclidean"
- "sklearn.model_selection.GridSearchCV"
- "sklearn.cluster.KMeans"
- "sklearn.svm.SVC"
- "sklearn.ensemble.RandomForestClassifier"
- "matplotlib"
- "matplotlib.pyplot"
- "seaborn"

When I run the command:
"python -V"
in my terminal to check my version of Python, I get the following:
"Python 3.6.2 :: Anaconda, Inc."