#------------------------------------------------------------
#Import libraries

import pandas as pd

import scipy as scp
from scipy.spatial.distance import euclidean

#from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier

import matplotlib as mplt
import matplotlib.pyplot as plt
import seaborn as sns

#------------------------------------------------------------

alpha = 0.3

#------------------------------------------------------------
#Kick it: Question 1
traininput = pd.read_table('data/trainInput.csv', header=None, sep=' ').values
traintarget = pd.read_table('data/trainTarget.csv', header=None, sep=' ').values[:,0]
testinput = pd.read_table('data/testInput.csv', header=None, sep=' ').values
testtarget = pd.read_table('data/testTarget.csv', header=None, sep=' ').values[:,0]

class_names = ['player team 1', 
               'player team 2', 
               'goalkeeper team 1',
               'goalkeeper team 2',
               'referee',
               'group',
               'error']

freqs = pd.Series(traintarget).value_counts(normalize=True).sort_index().round(3)
freqs = pd.DataFrame({'class index': freqs.index, 'class': class_names, 'frequency': freqs.values})
freqs.to_latex(buf='output/class_freqs_table.tex', index=False)

#------------------------------------------------------------
#Kick it: Question 2

pca = PCA(n_components=traininput.shape[1])
pca.fit(traininput)

fig, axs = plt.subplots(1,3,sharey=True,figsize=(14,6))
axs[0].plot(range(1,6), pca.explained_variance_ratio_[:5])
axs[1].plot(range(1,16), pca.explained_variance_ratio_[:15])
axs[2].plot(range(1,193), pca.explained_variance_ratio_)
axs[0].set_ylabel('normalized eigenvalue', fontsize='large')
axs[0].set_xlabel('the nth principal component', fontsize='large')
axs[1].set_xlabel('the nth principal component', fontsize='large')
axs[2].set_xlabel('the nth principal component', fontsize='large')
axs[0].xaxis.set_major_locator(mplt.ticker.MaxNLocator(integer=True))
axs[1].xaxis.set_major_locator(mplt.ticker.MaxNLocator(integer=True))
axs[2].xaxis.set_major_locator(mplt.ticker.MaxNLocator(integer=True))
fig.savefig('output/pca_plot_1.jpg')

fig, axs = plt.subplots(1,3,sharey=True,figsize=(14,6))
axs[0].plot(range(1,6), scp.cumsum(pca.explained_variance_ratio_[:5]))
axs[1].plot(range(1,16), scp.cumsum(pca.explained_variance_ratio_[:15]))
axs[2].plot(range(1,193), scp.cumsum(pca.explained_variance_ratio_))
axs[0].set_ylabel('explained variance', fontsize='large')
axs[0].set_xlabel('first n principal components', fontsize='large')
axs[1].set_xlabel('first n principal components', fontsize='large')
axs[2].set_xlabel('first n principal components', fontsize='large')
axs[0].xaxis.set_major_locator(mplt.ticker.MaxNLocator(integer=True))
axs[1].xaxis.set_major_locator(mplt.ticker.MaxNLocator(integer=True))
axs[2].xaxis.set_major_locator(mplt.ticker.MaxNLocator(integer=True))
fig.savefig('output/pca_plot_2.jpg')

explained_var = pd.Series(scp.cumsum(pca.explained_variance_ratio_)[:15], index=range(1,16))
explained_var = pd.DataFrame({'First n princ. comp.': explained_var.index, 'Explained variance': explained_var.values})
cols = [explained_var.columns[1]] + [explained_var.columns[0]]
explained_var = explained_var[cols]
explained_var.to_latex(buf='output/explained_var_table.tex',index=False)

traininput_transformed = pca.transform(traininput)

fig, axs = plt.subplots(1,1,figsize=(12,8))

targets = scp.unique(traintarget)
colors = ['red', 'blue', 'orange', 'purple', 'brown', 'green', 'grey']
handles = [axs.scatter(traininput_transformed[traintarget==target][:,0], 
            traininput_transformed[traintarget==target][:,1], 
            c=colors[target], alpha=alpha) for target in targets]
axs.set_xlabel('Principal component 1', fontsize='large')
axs.set_ylabel('Principal component 2', fontsize='large')
axs.legend(handles,class_names)
fig.savefig('output/pca_scatter_plot.jpg')

fig, axs = plt.subplots(1,1,figsize=(12,8))
handles = [axs.scatter(traininput_transformed[traintarget==target][:,2], 
            traininput_transformed[traintarget==target][:,3], 
            c=colors[target],
            alpha=alpha) for target in targets]
axs.set_xlabel('Principal component 3', fontsize='large')
axs.set_ylabel('Principal component 4', fontsize='large')
axs.legend(handles,class_names)
fig.savefig('output/pca_scatter_plot2.jpg')
#------------------------------------------------------------
#Kick it: Question 3

#normalizer = StandardScaler().fit(traininput)
traininput_norm = traininput #normalizer.transform(traininput)

init_means = scp.array([traininput_norm[traintarget==target][0] for target in targets])
kmeans = KMeans(init=init_means, n_clusters=7, n_init=1, algorithm='full')
kmeans.fit(traininput_norm)
kmeans_centers_transformed = pca.transform(kmeans.cluster_centers_)#normalizer.inverse_transform(kmeans.cluster_centers_))

fig, axs = plt.subplots(1,1,figsize=(12,8))
handles1 = [axs.scatter(traininput_transformed[traintarget==target][:,0], 
            traininput_transformed[traintarget==target][:,1], 
            c=colors[target],
            alpha=alpha) for target in targets]
[axs.scatter(kmeans_centers_transformed[target,0], 
             kmeans_centers_transformed[target,1], 
             c='black',
             marker='D',
             s=60) for target in targets]
axs.set_xlabel('Principal component 1', fontsize='large')
axs.set_ylabel('Principal component 2', fontsize='large')
axs.legend(handles1,class_names)
fig.savefig('output/kmeans_plot1.jpg')

class_means = scp.array([scp.mean(traininput_norm[traintarget==target], axis=0) for target in targets])

class_means_transformed = pca.transform(class_means) #normalizer.inverse_transform(class_means))

fig, axs = plt.subplots(1,1,figsize=(12,8))
handles1 = [axs.scatter(traininput_transformed[traintarget==target][:,0], 
            traininput_transformed[traintarget==target][:,1], 
            c=colors[target],
            alpha=alpha) for target in targets]
[axs.scatter(kmeans_centers_transformed[target,0], 
             kmeans_centers_transformed[target,1], 
             c='black',
             marker='D',
             s=60) for target in targets]
[axs.scatter(class_means_transformed[target,0], 
             class_means_transformed[target,1], 
             c=colors[target],
             linewidth=2,
             edgecolors='black',
             marker='s') for target in targets]
axs.set_xlabel('Principal component 1', fontsize='large')
axs.set_ylabel('Principal component 2', fontsize='large')
axs.legend(handles1,class_names)
fig.savefig('output/kmeans_plot2.jpg')

fig, axs = plt.subplots(1,1,figsize=(12,8))
handles1 = [axs.scatter(traininput_transformed[traintarget==target][:,0], 
            traininput_transformed[traintarget==target][:,1], 
            c='black',
            alpha=alpha) for target in targets]
axs.set_xlabel('Principal component 1', fontsize='large')
axs.set_ylabel('Principal component 2', fontsize='large')
fig.savefig('output/kmeans_plot3.jpg')

clusters = kmeans.predict(traininput)
clusterindex = scp.unique(clusters)

fig, axs = plt.subplots(1,1,figsize=(12,8))
colormap = mplt.cm.get_cmap(name='Dark2').colors
[axs.scatter(traininput_transformed[clusters==clus][:,0], 
            traininput_transformed[clusters==clus][:,1], 
            c=colormap[clus+1],
            alpha=alpha) for clus in clusterindex]
[axs.scatter(kmeans_centers_transformed[clus,0], 
             kmeans_centers_transformed[clus,1], 
             c='black',
             marker='D',
             s=60) for clus in clusterindex]
axs.set_xlabel('Principal component 1', fontsize='large')
axs.set_ylabel('Principal component 2', fontsize='large')
fig.savefig('output/kmeans_plot4.jpg')
#------------------------------------------------------------
#Kick it: Question 5

clf = RandomForestClassifier(n_estimators=50, criterion='entropy', max_features='sqrt', random_state=154)
clf.fit(traininput, traintarget)
res = pd.DataFrame({'Training score': clf.score(traininput, traintarget), 'Test score': round(clf.score(testinput, testtarget),3)}, index=[0])
res[['Training score', 'Test score']].to_latex(buf='output/rf_res_table.tex', index=False)

#------------------------------------------------------------
#Kick it: Question 6

# ## Question 6

traininput = pd.read_table('data/trainInputBinary.csv', header=None, sep=' ').values
traintarget = pd.read_table('data/trainTargetBinary.csv', header=None, sep=' ').values[:,0]
testinput = pd.read_table('data/testInputBinary.csv', header=None, sep=' ').values
testtarget = pd.read_table('data/testTargetBinary.csv', header=None, sep=' ').values[:,0]
traininput_zeros = traininput[traintarget==0]
traininput_ones = traininput[traintarget==1]

def min_distance(source, targets) : 
    return scp.amin(scp.apply_along_axis(lambda x : euclidean(x, source), 1, targets))

def min_distances(sources, targets) :
    return scp.apply_along_axis(lambda x : min_distance(x, targets), 1, sources)

def jaakkola() :
    zeros_to_ones = min_distances(traininput_zeros, traininput_ones)
    ones_to_zeros = min_distances(traininput_ones, traininput_zeros)
    sigmajak = scp.median(scp.concatenate((zeros_to_ones, ones_to_zeros)))
    return (1/(2*(sigmajak**2)))

jak = jaakkola()
pd.DataFrame({'Jaakoola heuristic for gamma': round(jak, 3)}, index=[0]).to_latex(buf='output/jaakoola.tex', index=False)

    #tuned = SVC(kernel='rbf',gamma=clf.best_params_['gamma'], C=clf.best_params_['C'])
    #tuned.fit(traininput, traintarget)
    #res['training score'] = tuned.score(traininput, traintarget)

def cross_validate(b) :

    param_grid = {'C' : scp.logspace(-1,3,5,base=b), 'gamma' : scp.logspace(-3,3,7,base=b)*jak}

    clf = GridSearchCV(SVC(kernel = 'rbf'), param_grid)
    clf.fit(traininput,traintarget)

    res = clf.best_params_
    res['C'] = round(res['C'], 3)
    res['gamma'] = round(res['gamma'], 3)
    tuned = SVC(kernel='rbf',gamma=clf.best_params_['gamma'], C=clf.best_params_['C'])
    tuned.fit(traininput, traintarget)
    res['training score'] = round(tuned.score(traininput, traintarget), 3)
    res['validation score'] = round(clf.best_score_, 3)
    res['test score'] = round(clf.score(testinput, testtarget), 3)
    res = pd.DataFrame(res, index=[0])
    res = res[['C', 'gamma', 'training score', 'validation score', 'test score']]
    res.to_latex(buf='output/svm_cv_res_' + str(int(round(b))) + '.tex', index=False)

    cross_results = pd.DataFrame(clf.cv_results_)[['mean_test_score','params']]
    cross_results['C'] = cross_results.params.apply(lambda d : d['C'])
    cross_results['gamma'] = cross_results.params.apply(lambda d : d['gamma'])
    cross_results = cross_results.rename(columns = {'mean_test_score' : 'mean_val_score'})
    cross_results = cross_results.drop('params', axis=1)
    cross_results = cross_results.pivot(index = 'C', columns = 'gamma', values = 'mean_val_score')

    heatmap = sns.heatmap(cross_results, cmap='Greens', annot = True, fmt='.3g')
    heatmap.set_xticklabels(scp.around(scp.array(cross_results.columns), 2))
    heatmap.set_xticklabels(scp.around(scp.array(cross_results.index), 2))
    heatmap = heatmap.get_figure()
    heatmap.savefig('output/cv_heatmap_'+str(int(round(b)))+'.jpg', bbox_inches='tight')

    return res

cross_validate(2)
cross_validate(scp.exp(1))
cross_validate(10)