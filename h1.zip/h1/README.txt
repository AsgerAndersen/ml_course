Author: Asger Andersen

I have implemented all my code in Python. I have used Jupyter Notebooks to write and run my code. 

In the folder nearest_neighbour, there is a notebook by the name nearest_neighbour.ipynb. When the entire notebook is run, all the results from the section Nearest Neighbour are reproduced. 

In the folder linear_regression, there is a notebook by the name linear_regression.ipynb. When the entire notebook is run, all the results from the section Linear Regression are reproduced.